var searchData=
[
  ['bool',['bool',['../sparse_8h.html#af6a258d8f3ee5206d682d799316314b1',1,'sparse.h']]]
];
