var searchData=
[
  ['val',['val',['../structelem.html#a52a0b099052bdf7611aa32acdb3f5449',1,'elem']]]
];
