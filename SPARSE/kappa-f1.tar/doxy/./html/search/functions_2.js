var searchData=
[
  ['is_5fequal_5fsmat',['is_equal_smat',['../sparse_8c.html#a4232552afd0fdc736d90fded1f272759',1,'is_equal_smat(smatrix_t *a, smatrix_t *b):&#160;sparse.c'],['../sparse_8h.html#a4232552afd0fdc736d90fded1f272759',1,'is_equal_smat(smatrix_t *a, smatrix_t *b):&#160;sparse.c']]]
];
