var indexSectionsWithContent =
{
  0: "bcefgilmnpstv",
  1: "es",
  2: "s",
  3: "fgilnpst",
  4: "cmnv",
  5: "be",
  6: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "File",
  3: "Funzioni",
  4: "Variabili",
  5: "Ridefinizioni di tipo (typedef)",
  6: "Tipi enumerati (enum)"
};

