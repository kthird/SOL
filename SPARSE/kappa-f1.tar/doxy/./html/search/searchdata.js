var indexSectionsWithContent =
{
  0: "cemnsv",
  1: "es",
  2: "cmnv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "Variabili"
};

