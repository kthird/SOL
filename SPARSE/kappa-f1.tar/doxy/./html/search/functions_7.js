var searchData=
[
  ['transp_5fsmat',['transp_smat',['../sparse_8c.html#a7b9192596db334fe30a652e05ab45987',1,'transp_smat(smatrix_t *a):&#160;sparse.c'],['../sparse_8h.html#a7b9192596db334fe30a652e05ab45987',1,'transp_smat(smatrix_t *a):&#160;sparse.c']]]
];
