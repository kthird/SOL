var searchData=
[
  ['sparse_2ec',['sparse.c',['../sparse_8c.html',1,'']]],
  ['sparse_2eh',['sparse.h',['../sparse_8h.html',1,'']]],
  ['sparse_5fdocenti_2ec',['sparse_docenti.c',['../sparse__docenti_8c.html',1,'']]]
];
