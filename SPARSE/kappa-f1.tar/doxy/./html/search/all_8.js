var searchData=
[
  ['ncol',['ncol',['../structsmatrix__t.html#a7a7218430298fc18a42dfa43ecc41635',1,'smatrix_t']]],
  ['new_5fsmat',['new_smat',['../sparse_8c.html#a13f7785dace4a2981b9b6f810ca34115',1,'new_smat(unsigned n, unsigned m):&#160;sparse.c'],['../sparse_8h.html#a13f7785dace4a2981b9b6f810ca34115',1,'new_smat(unsigned n, unsigned m):&#160;sparse.c']]],
  ['next',['next',['../structelem.html#ab9cf5c2e1c9a0ec2938275b90d39d5ca',1,'elem']]],
  ['nrow',['nrow',['../structsmatrix__t.html#ae0b8f31ddab7ed23ca14a46758291f37',1,'smatrix_t']]]
];
