var searchData=
[
  ['col',['col',['../structelem.html#aca409f3a7c1c9621b262a230c78ef37b',1,'elem']]]
];
