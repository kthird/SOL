var searchData=
[
  ['load_5fsmat',['load_smat',['../sparse_8c.html#ac5049cd89f46bff8cd028382edf931e6',1,'load_smat(FILE *fd):&#160;sparse.c'],['../sparse_8h.html#ac5049cd89f46bff8cd028382edf931e6',1,'load_smat(FILE *fd):&#160;sparse.c']]],
  ['loadbin_5fsmat',['loadbin_smat',['../sparse_8c.html#a1bb39d59a532967d5f507a19700aafb1',1,'loadbin_smat(FILE *fd):&#160;sparse.c'],['../sparse_8h.html#a1bb39d59a532967d5f507a19700aafb1',1,'loadbin_smat(FILE *fd):&#160;sparse.c']]]
];
