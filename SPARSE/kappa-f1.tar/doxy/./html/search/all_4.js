var searchData=
[
  ['smatrix_5ft',['smatrix_t',['../structsmatrix__t.html',1,'']]]
];
