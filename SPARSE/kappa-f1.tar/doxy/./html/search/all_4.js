var searchData=
[
  ['get_5felem',['get_elem',['../sparse_8c.html#a03efbfc08da3aa936597103784ddbe45',1,'get_elem(smatrix_t *m, unsigned i, unsigned j, double *pd):&#160;sparse.c'],['../sparse_8h.html#a03efbfc08da3aa936597103784ddbe45',1,'get_elem(smatrix_t *m, unsigned i, unsigned j, double *pd):&#160;sparse.c']]],
  ['get_5felem_5frow',['get_elem_row',['../sparse_8c.html#a23f27b0ac759a8c6cf94ca624a7367d3',1,'get_elem_row(elem_t *r, int j, double *pd):&#160;sparse.c'],['../sparse_8h.html#a23f27b0ac759a8c6cf94ca624a7367d3',1,'get_elem_row(elem_t *r, int j, double *pd):&#160;sparse.c']]]
];
