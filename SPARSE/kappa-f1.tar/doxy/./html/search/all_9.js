var searchData=
[
  ['print_5fsmat',['print_smat',['../sparse_8h.html#abe7c306fd1022398d6ee66088635d548',1,'print_smat(FILE *f, smatrix_t *l):&#160;sparse_docenti.c'],['../sparse__docenti_8c.html#a908b6cb8261c0131e8c71d842a4381c1',1,'print_smat(FILE *f, smatrix_t *a):&#160;sparse_docenti.c']]],
  ['prod_5fsmat',['prod_smat',['../sparse_8c.html#a633a6b934732ad44f5cf73e9c55c54e9',1,'prod_smat(smatrix_t *a, smatrix_t *b):&#160;sparse.c'],['../sparse_8h.html#a633a6b934732ad44f5cf73e9c55c54e9',1,'prod_smat(smatrix_t *a, smatrix_t *b):&#160;sparse.c']]],
  ['put_5felem',['put_elem',['../sparse_8c.html#a19ab77e854480bb2c9e5032bc3f0ab9f',1,'put_elem(smatrix_t *m, unsigned i, unsigned j, double d):&#160;sparse.c'],['../sparse_8h.html#a19ab77e854480bb2c9e5032bc3f0ab9f',1,'put_elem(smatrix_t *m, unsigned i, unsigned j, double d):&#160;sparse.c']]],
  ['put_5felem_5frow',['put_elem_row',['../sparse_8c.html#a098b33ab9b543c109d655b9afc081bb7',1,'put_elem_row(elem_t **r, int j, double d):&#160;sparse.c'],['../sparse_8h.html#a098b33ab9b543c109d655b9afc081bb7',1,'put_elem_row(elem_t **r, int j, double d):&#160;sparse.c']]]
];
