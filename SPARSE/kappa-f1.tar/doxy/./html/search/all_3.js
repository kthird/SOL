var searchData=
[
  ['free_5frow',['free_row',['../sparse_8c.html#a58e3ead06f0ecc684dfc90538947343a',1,'free_row(elem_t **pr):&#160;sparse.c'],['../sparse_8h.html#a58e3ead06f0ecc684dfc90538947343a',1,'free_row(elem_t **pr):&#160;sparse.c']]],
  ['free_5fsmat',['free_smat',['../sparse_8c.html#ad3596ce2e271a24fada5c85f3b8ce0af',1,'free_smat(smatrix_t **pm):&#160;sparse.c'],['../sparse_8h.html#ad3596ce2e271a24fada5c85f3b8ce0af',1,'free_smat(smatrix_t **pm):&#160;sparse.c']]]
];
