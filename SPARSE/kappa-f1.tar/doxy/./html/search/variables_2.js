var searchData=
[
  ['ncol',['ncol',['../structsmatrix__t.html#a7a7218430298fc18a42dfa43ecc41635',1,'smatrix_t']]],
  ['next',['next',['../structelem.html#ab9cf5c2e1c9a0ec2938275b90d39d5ca',1,'elem']]],
  ['nrow',['nrow',['../structsmatrix__t.html#ae0b8f31ddab7ed23ca14a46758291f37',1,'smatrix_t']]]
];
