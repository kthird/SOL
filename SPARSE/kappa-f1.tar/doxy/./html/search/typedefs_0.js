var searchData=
[
  ['bool_5ft',['bool_t',['../sparse_8h.html#a4ed992ceefff896353c1727143529d16',1,'sparse.h']]]
];
