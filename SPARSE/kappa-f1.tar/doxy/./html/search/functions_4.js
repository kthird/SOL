var searchData=
[
  ['new_5fsmat',['new_smat',['../sparse_8c.html#a13f7785dace4a2981b9b6f810ca34115',1,'new_smat(unsigned n, unsigned m):&#160;sparse.c'],['../sparse_8h.html#a13f7785dace4a2981b9b6f810ca34115',1,'new_smat(unsigned n, unsigned m):&#160;sparse.c']]]
];
