var searchData=
[
  ['save_5fsmat',['save_smat',['../sparse_8c.html#a9ee2597119d106f30a1ba43ba3d6c642',1,'save_smat(FILE *fd, smatrix_t *mat):&#160;sparse.c'],['../sparse_8h.html#a9ee2597119d106f30a1ba43ba3d6c642',1,'save_smat(FILE *fd, smatrix_t *mat):&#160;sparse.c']]],
  ['savebin_5fsmat',['savebin_smat',['../sparse_8c.html#a8529b8bb59f8d259731ef88e5deb6d57',1,'savebin_smat(FILE *fd, smatrix_t *mat):&#160;sparse.c'],['../sparse_8h.html#a8529b8bb59f8d259731ef88e5deb6d57',1,'savebin_smat(FILE *fd, smatrix_t *mat):&#160;sparse.c']]],
  ['smatrix_5ft',['smatrix_t',['../structsmatrix__t.html',1,'']]],
  ['sparse_2ec',['sparse.c',['../sparse_8c.html',1,'']]],
  ['sparse_2eh',['sparse.h',['../sparse_8h.html',1,'']]],
  ['sparse_5fdocenti_2ec',['sparse_docenti.c',['../sparse__docenti_8c.html',1,'']]],
  ['sum_5fsmat',['sum_smat',['../sparse_8c.html#afa8c4ca1cb9e4e55f40dd35faa1d9f85',1,'sum_smat(smatrix_t *a, smatrix_t *b):&#160;sparse.c'],['../sparse_8h.html#afa8c4ca1cb9e4e55f40dd35faa1d9f85',1,'sum_smat(smatrix_t *a, smatrix_t *b):&#160;sparse.c']]]
];
